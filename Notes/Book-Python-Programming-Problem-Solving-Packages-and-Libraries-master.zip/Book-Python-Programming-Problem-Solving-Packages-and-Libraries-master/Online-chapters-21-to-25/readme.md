This repository contains the chapters 21 to 25 and Appendix 4 of my book Python Programming: Problem Solving, Packages and Libraries available 
[here](https://www.amazon.in/Python-Programming-Problem-Packages-Libraries/dp/9353168007/ref=sr_1_2?dchild=1&qid=1588813224&refinements=p_27%3AGupta+Biswas&s=books&sr=1-2 "Book on Amazon").

The chapters are:- 
- Chapter 21:- Matplotlib 
- Chapter 22:- Mapping Applications in Python (Basemap and Folium)
- Chapter 23:- Some Common Python Libraries for Web
- Chapter 24:- Natural Language Processing
- Chapter 25:- Gensim
- Appendix 4:- Vector Space Model
